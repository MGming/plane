#include "GameScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"PlaneHero.h"
#include"PlaneEnemy.h"
#include"Item.h"
#include"HeroBullet.h"
#include"Boss.h"
#include"SoundManager.h"
#include"GameMenu.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;

GameScene* GameScene::m_gameLayer = nullptr;
BulletManager* GameScene::m_bulletManager = nullptr;
ItemManager* GameScene::m_itemManager = nullptr;
EnemyManager* GameScene::m_enemyManager = nullptr;
MessageManager* GameScene::m_messageManager = nullptr;
HeroManager* GameScene::m_heroManager=nullptr;

Scene* GameScene::createScene()
{
	//����һ��û����������������
	auto scene = Scene::createWithPhysics();
	scene->getPhysicsWorld()->setGravity(Vect(0, 0));

	//�������Ի�ͼ
	//scene->getPhysicsWorld()->setDebugDrawMask(PhysicsWorld::DEBUGDRAW_ALL);
	m_gameLayer = GameScene::create();
	scene->addChild(m_gameLayer);
	return scene;
}

bool GameScene::init()
{
    if ( !Layer::init() )
    {
        return false;
    }
	auto winSize = Director::getInstance()->getWinSize();
	this->playMap();

	//���ű�������
	SoundManager::playGameBgm();

	/**�����ӵ�������**/
	m_bulletManager=(BulletManager*)BulletManager::create();
	this->addChild(m_bulletManager, 1);

	/**������Ʒ������**/
	m_itemManager = (ItemManager*)ItemManager::create();
	this->addChild(m_itemManager, 2);

	/**����л�������**/
	m_enemyManager = (EnemyManager*)EnemyManager::create();
	this->addChild(m_enemyManager, 3);

	/**�����ҷ�ս��������**/
	m_heroManager = (HeroManager*)HeroManager::create();
	this->addChild(m_heroManager, 4);

	/**������Ϣ������**/
	m_messageManager = (MessageManager*)MessageManager::create();
	this->addChild(m_messageManager, 5);
	
	//�ҷ�ս���볡���������������Ļ���������������ҷ��ɻ�
	auto func= CallFunc::create([this]() {this->addPlaneControl(); });
	auto dt = DelayTime::create(2.5);
	auto act = Sequence::create(dt, func, nullptr);
	this->runAction(act);

	//������ײ�Ӵ��¼�����
	auto contactListener = EventListenerPhysicsContact::create();
	contactListener->onContactBegin= CC_CALLBACK_1(GameScene::dealWithContact, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(contactListener, this);
	//this->setSwallowsTouches(0);

    return true;	
}
void GameScene::addPlaneControl()
{   
	auto winSize = Director::getInstance()->getWinSize();
	//������Ļ�����¼�
	auto touchListener=EventListenerTouchOneByOne::create();
	touchListener->setSwallowTouches(true);
	
	auto hero = (PlaneHero*)this->getHeroManager()->getChildByTag(HERO_TAG);
	//������ʼ
	touchListener->onTouchBegan=[hero,this](Touch* pTouch, Event* pEvent)
	{
		
		//hero->setContentSize(Size(30,31));
		auto heroPos = hero->getPosition();
		auto heroSize = hero->getContentSize();
		auto touchPos = pTouch->getLocation();
		
		if (fabs(touchPos.x - heroPos.x) <= heroSize.width / 2 && fabs(touchPos.y - heroPos.y) <= heroSize.height / 2)
		{
			//log("choose hero!");
			return true;
		}
		else
			return false;
	};
	touchListener->onTouchMoved = [hero,this,winSize](Touch* pTouch, Event* pEvent)
	{
		auto deltaPosition = pTouch->getDelta();
		//auto hero = (PlaneHero*)rootNode->getChildByTag(HERO_TAG);
		auto oldPosition = hero->getPosition();
		hero->setPosition(Vec2(oldPosition.x+deltaPosition.x, oldPosition.y + deltaPosition.y));
		if (hero->getPositionY() < hero->getContentSize().height / 2 || hero->getPositionY() > winSize.height - hero->getContentSize().height / 2
			||hero->getPositionX() < hero->getContentSize().width / 2 || hero->getPositionX() > winSize.width - hero->getContentSize().width / 2)
		{
			hero->setPosition(oldPosition);
		}
		return true;
	};
	
	_eventDispatcher->addEventListenerWithSceneGraphPriority(touchListener,hero);
}

void GameScene::playMap()
{
	auto winSize2 = Director::getInstance()->getWinSize();
	auto map1 = Sprite::create("Map3.png");
	Size mSize = map1->getContentSize();
	map1->setScaleX(winSize2.width / mSize.width);
	map1->setScaleY(winSize2.width/ mSize.width);
	map1->setAnchorPoint(Vec2(0, 0));
	map1->setPosition(Vec2(0, 0));
	this->addChild(map1, 0);
	

	auto move1 = MoveTo::create(10, Vec2(0, -winSize2.width / mSize.width*mSize.height));
	auto callFunc1 = CallFunc::create([map1, winSize2, mSize]() {map1->setPosition(Vec2(0,0)); log("map1"); });
	//auto move1_1= MoveTo::create(20, Vec2(0, -winSize2.width / mSize.width*mSize.height));
	auto action1 = RepeatForever::create(Sequence::create(move1,callFunc1,nullptr));
	//auto actionFinal = Sequence::create(action1,nullptr);
	map1->runAction(action1);
	

	/************************************************************************************/


	auto map2 = Sprite::create("Map3.png");
	Size mSize2 = map2->getContentSize();
	map2->setScaleX(winSize2.width / mSize.width);
	map2->setScaleY(winSize2.height / mSize.width);
	map2->setAnchorPoint(Vec2(0, 0));
	map2->setPosition(0, winSize2.width/mSize.width*mSize.height);
	this->addChild(map2, 0);

	auto move2 = MoveTo::create(10, Vec2(0,0));
	auto callFunc2 = CallFunc::create([map2, winSize2, mSize]() {map2->setPosition(Vec2(0, winSize2.width / mSize.width*mSize.height)); });
	auto action2 = Sequence::create(move2, callFunc2, nullptr);
	map2->runAction(RepeatForever::create(action2));
}

bool GameScene::dealWithContact(PhysicsContact& contact)
{

	//log("contact");
	auto node1 = contact.getShapeA()->getBody()->getNode();
	auto node2 = contact.getShapeB()->getBody()->getNode();

	if (!node1 || !node2)
		return false;
	auto tag1 = node1->getTag();
	auto tag2 = node2->getTag();

	//�ҷ��ӵ��͵л�������ײ
	if ((tag1 == HERO_BULLET_TAG && tag2 == ENEMY_TAG) || (tag2 == HERO_BULLET_TAG && tag1 == ENEMY_TAG))
	{
		//log("bullet&&enemy");
		if (tag1 == HERO_BULLET_TAG && tag2 == ENEMY_TAG)
		{
			//int bulletPower = node1->getBulletPower();			
			((PlaneEnemy*)node2)->getHurt(((HeroBullet*)node1)->getBulletPower());
			 node1->removeFromParent();
		}
		else if (tag2 == HERO_BULLET_TAG && tag1 == ENEMY_TAG)
		{
			//int bulletPower = node1->getBulletPower();			
			((PlaneEnemy*)node1)->getHurt(((HeroBullet*)node2)->getBulletPower());
			node2->removeFromParent();
		}
	}

	//�ҷ�ս����BOSS�л�������ײ
	if ((tag1 == HERO_TAG && tag2 == BOSS_TAG) || (tag2 == HERO_TAG && tag1 == BOSS_TAG))
	{
		//log("hero&&boss");
		
		if (tag1 == HERO_TAG && tag2 == BOSS_TAG)
		{
			//int bulletPower = node1->getBulletPower();			
			//((Boss*)node2)->getHurt(((HeroBullet*)node1)->getBulletPower());
			((PlaneHero*)node1)->getHurt(5);
			if(!((PlaneHero*)node1)->isLive())
				gameOver();
		}
		else if (tag2 == HERO_TAG && tag1 == BOSS_TAG)
		{
			//int bulletPower = node1->getBulletPower();			
			//((Boss*)node1)->getHurt(((HeroBullet*)node2)->getBulletPower());
			((PlaneHero*)node2)->getHurt(5);
			if (!((PlaneHero*)node2)->isLive())
				gameOver();
		}
	}
	//���ӵ���BOSS�л�������ײ
	if ((tag1 == HERO_BULLET_TAG && tag2 == BOSS_TAG) || (tag2 == HERO_BULLET_TAG && tag1 == BOSS_TAG))
	{
		//log("bullet&&boss");
		if (tag1 == HERO_BULLET_TAG && tag2 == BOSS_TAG)
		{
			//int bulletPower = node1->getBulletPower();			
		    ((Boss*)node2)->getHurt(((HeroBullet*)node1)->getBulletPower());
			node1->removeFromParent();
			if (!((Boss*)node2)->isLive())
				gameVictory();
		}
		else if (tag2 == HERO_BULLET_TAG && tag1 == BOSS_TAG)
		{
			//int bulletPower = node1->getBulletPower();			
			((Boss*)node1)->getHurt(((HeroBullet*)node2)->getBulletPower());
			node2->removeFromParent();
			if (!((Boss*)node1)->isLive())
				gameVictory();
		}
	}
	//�ҷ�ս���͵л�������ײ
	else if ((tag1 == HERO_TAG && tag2 == ENEMY_TAG) || (tag2 == HERO_TAG && tag1 == ENEMY_TAG))
	{
		//node1->removeFromParent();
		//node2->removeFromParent();
		
		//log("hero&&enemy");
		if (tag1 == HERO_TAG && tag2 == ENEMY_TAG)
		{
			//int bulletPower = node1->getBulletPower();			
			//((Boss*)node2)->getHurt(((HeroBullet*)node1)->getBulletPower());
			((PlaneHero*)node1)->getHurt(5);
			if (!((PlaneHero*)node1)->isLive())
				gameOver();
		}
		else if (tag2 == HERO_TAG && tag1 ==ENEMY_TAG)
		{
			//int bulletPower = node1->getBulletPower();			
			//((Boss*)node1)->getHurt(((HeroBullet*)node2)->getBulletPower());
			((PlaneHero*)node2)->getHurt(5);
			if (!((PlaneHero*)node2)->isLive())
				gameOver();
		}
	}
	//�ҷ�ս���͵з��ӵ�������ײ
	else if ((tag1 == HERO_TAG && tag2 == ENEMY_BULLET_TAG) || (tag2 == HERO_TAG && tag1 == ENEMY_BULLET_TAG))
	{
		//node1->removeFromParent();
		//node2->removeFromParent();
		//log("hero&&enemyBullet");
		
		if (tag1 == HERO_TAG && tag2 == ENEMY_BULLET_TAG)
		{
			//int bulletPower = node1->getBulletPower();			
			//((Boss*)node2)->getHurt(((HeroBullet*)node1)->getBulletPower());
			((PlaneHero*)node1)->getHurt(5);
			node2->removeFromParent();
			if (!((PlaneHero*)node1)->isLive())
				gameOver();
		}
		else if (tag2 == HERO_TAG && tag1 == ENEMY_BULLET_TAG)
		{
			//int bulletPower = node1->getBulletPower();			
			//((Boss*)node1)->getHurt(((HeroBullet*)node2)->getBulletPower());
			((PlaneHero*)node2)->getHurt(5);
			node1->removeFromParent();
			if (!((PlaneHero*)node2)->isLive())
				gameOver();
		}	
	}

	//�ҷ��ӵ��͵з��ӵ�������ײ
	else if ((tag1 == HERO_BULLET_TAG && tag2 == ENEMY_BULLET_TAG) || (tag2 == HERO_BULLET_TAG && tag1 == ENEMY_BULLET_TAG))
	{
		//node1->removeFromParent();
		//node2->removeFromParent();
		//log("heroBullet&&enemyBullet");

	}
	//�ҷ�ս���͵��߷�����ײ
	else if ((tag1 == HERO_TAG && tag2 ==ITEM_TAG) || (tag2 == HERO_TAG && tag1 == ITEM_TAG))
	{
		if (tag1 == HERO_TAG)
		{ 
			//auto p = (PlaneHero*)node1;
			((PlaneHero*)node1)->getItem(((Item*)node2));
			node2->removeFromParent();
		}
		else
		{
			((PlaneHero*)node2)->getItem(((Item*)node1));
			node1->removeFromParent();
		}
		//log("hero&&item");
	}
	return true;

}
void GameScene::gameOver()
{
	//log("gameOver");
	_eventDispatcher->removeAllEventListeners();
	auto winSize = Director::getInstance()->getWinSize();
	auto overBg = Sprite::create("GameOver.png");
	auto overBgSize = overBg->getContentSize();
	overBg->setScaleX(winSize.width / overBgSize.width);
	overBg->setScaleY(winSize.height / overBgSize.height);
	overBg->setAnchorPoint(Vec2(0, 0));
	overBg->setVisible(0);
	this->addChild(overBg,10);
	
	auto func = CallFunc::create([overBg]() {overBg->setVisible(1); SoundManager::playGameOverSound(); });
	auto func2 = CallFunc::create([this]() {Director::getInstance()->replaceScene(TransitionFade::create(0.5f,GameMenu::createScene())); });
	auto dt = DelayTime::create(2);
	auto dt2 = DelayTime::create(5);
	auto overAction = Sequence::create(dt, func,dt2,func2,nullptr);
	this->runAction(overAction);
	return;
}
void GameScene::gameVictory()
{
	//log("gameVictory");
	_eventDispatcher->removeAllEventListeners();
	auto winSize = Director::getInstance()->getWinSize();
	auto winBg = Sprite::create("GameVictory.png");
	winBg->setPosition(Vec2(winSize.width / 2, winSize.height / 1.5));
	winBg->setVisible(0);
	winBg->setScale(0.4);
	this->addChild(winBg, 10);
	
	auto func = CallFunc::create([winBg]() {winBg->setVisible(1); winBg->runAction(ScaleTo::create(0.25,1)); SoundManager::playMissionCompleteSound(); });
	auto func2 = CallFunc::create([this]() {Director::getInstance()->replaceScene(TransitionFade::create(1.0f, GameMenu::createScene())); });
	auto dt = DelayTime::create(1);
	auto dt2 = DelayTime::create(3);
	auto winAction = Sequence::create(dt, func, dt2, func2, nullptr);
	this->runAction(winAction);
	return;
}

