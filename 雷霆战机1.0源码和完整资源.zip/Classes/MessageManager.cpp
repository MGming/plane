#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"MessageManager.h"
#include"PauseScene.h"
#include"SoundManager.h"



USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;
bool MessageManager::init()
{
	if (!Layer::init())
	{
		
		return false;
	}
	this->setSwallowsTouches(0);
    auto messageLayer= CSLoader::createNode("messageLayer.csb");
	auto size = messageLayer->getContentSize().height;
	messageLayer->setAnchorPoint(Vec2(0, 0));
	messageLayer->setPosition(Vec2(0, 0));
	//messageLayer->setSwallowsTouches(0);
	this->addChild(messageLayer);
	
	//��ȡ��ť
	m_panel = (Layout*)messageLayer->getChildByName("Panel");
	m_pauseButton= (Button*)Helper::seekWidgetByName(m_panel, "PauseButton");
	m_scoreText= (Text*)Helper::seekWidgetByName(m_panel, "ScoreText");
	m_bossPHBar=(LoadingBar*)Helper::seekWidgetByName(m_panel, "BossPHBar");

	m_panel->setSwallowTouches(0);
	m_bossPHBar->setVisible(0);
	//m_bossPHBar->setVisible(1);

	//��ť���¼�
	m_pauseButton->addTouchEventListener(CC_CALLBACK_2(MessageManager::pauseGame,this));

	
	//չʾ����
	schedule(schedule_selector(MessageManager::showScore), 1);
	return true;
}
void MessageManager::showScore(float dt)
{
	//m_score++;
	char buf[20] = { 0 };
	sprintf(buf, "%d", m_score);
	m_scoreText->setString(buf);
}
void MessageManager::addScore(int score)
{
	m_score += score;
}
void MessageManager::pauseGame(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		SoundManager::playPauseSound();
		Director::getInstance()->pushScene(PauseScene::createScene(getBgTexture()));
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}
}

RenderTexture*  MessageManager::getBgTexture()
{
	//����
	auto winSize = Director::getInstance()->getWinSize();
	auto tex = RenderTexture::create(winSize.width,winSize.height);
	tex->begin();
	this->getParent()->visit();//�õݹ鷽�����������ڵ���ӽڵ㲢��������
	tex->end();
	return tex;
}