#include"PlaneEnemy.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"GameScene.h"
#include"SoundManager.h"
#include"PlaneHero.h"

USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;
PlaneEnemy* PlaneEnemy::createWithEnemyType(int enemyType)
{
	PlaneEnemy* enemy = new PlaneEnemy();
	if (enemy&&enemy->init(enemyType))
	{
		enemy->autorelease();
		return enemy;
	}
	else
	{
		CC_SAFE_DELETE(enemy);
		return nullptr;
	}
}

bool PlaneEnemy::init(int enemyType)
{
	if (!Sprite::init())
	{
		return false;
	}
	this->m_live = true;
	this->m_enemyType =enemyType;
	String enemyName;
	switch (enemyType)
	{
	    case Enemy1: 
			         enemyName = "Plane1_0.png";
		             m_enemyLife = Enemy1_Life;
					 m_enemyVec = Enemy1_Vec;
					 m_enemyScore = Enemy1_Score;
					 this->setName("plane1");
		             break;
		case Enemy2:
			         enemyName = "Plane2_0.png";
			         m_enemyLife = Enemy2_Life;
			         m_enemyVec = Enemy2_Vec;
					 m_enemyScore = Enemy2_Score;
					 this->setName("plane2");
			         break;
		case Enemy3:
			         enemyName = "Plane3_0.png";
			         m_enemyLife = Enemy3_Life;
			         m_enemyVec = Enemy3_Vec;
					 m_enemyScore = Enemy3_Score;
					 this->setName("plane3");
			         break;
		case Enemy4:
			         enemyName = "E0.png";
			         m_enemyLife = Enemy4_Life;
			         m_enemyVec =0;
					 m_enemyScore = Enemy4_Score;
					 this->setName("E0");
			         break;
		case Enemy5:
			         enemyName = "E1.png";
			         m_enemyLife = Enemy5_Life;
			         m_enemyVec =0;
					 m_enemyScore = Enemy5_Score;
			         this->setName("E1");
			         break;
		case Enemy6:
			         enemyName = "E2.png";
			         m_enemyLife = Enemy6_Life;
			         m_enemyVec = 0;
					 m_enemyScore = Enemy6_Score;
			         this->setName("E2");
			         break;
		case Enemy7:
			         enemyName = "E3.png";
			         m_enemyLife = Enemy7_Life;
			         m_enemyVec = 0;
					 m_enemyScore = Enemy7_Score;
			         this->setName("E3");
			         break;
		case Enemy8:
			         enemyName = "E4.png";
			         m_enemyLife = Enemy8_Life;
			         m_enemyVec = 0;
					 m_enemyScore = Enemy8_Score;
			         this->setName("E4");
		           	break;
		case Enemy9:
			         enemyName = "E5.png";
			         m_enemyLife = Enemy9_Life;
			         m_enemyVec = 0;
					 m_enemyScore = Enemy9_Score;
			         this->setName("E5");
			         break;
	    default:
		             break;
	}
	this->initWithSpriteFrameName(enemyName.getCString());

	Vec2 vec[10];//��ŷɻ�����εĵ�
	memset(vec, 0, sizeof(vec));
	int vec_count = 0;//����ε���

	switch (enemyType)
	{
	    case Enemy1:
			vec[0] = { -23,20 };
			vec[1] = { 23,20 };
			vec[2] = { 0,-20};
			vec_count = 3;
			break;
		case Enemy2:
			vec[0] = { -20,15};
			vec[1] = { 20,15};
			vec[2] = { 0,-15};
			vec_count = 3;
			break;
		case Enemy3:
			vec[0] = { -17,16};
			vec[1] = { 17,16};
			vec[2] = { 0,-16};
			vec_count = 3;
			break;
		case Enemy4:
			vec[0] = { -22,12};
			vec[1] = { 22,12};
			vec[2] = { 22,-12};
			vec[3] = { -22,-12};
			vec_count = 4;
			break;
		case Enemy5:
			vec[0] = { -27,15 };
			vec[1] = { 27,15 };
			vec[2] = { 27,-15};
			vec[3] = { -27,-15};
			vec_count = 4;
			break;
		case Enemy6:
			vec[0] = { -27,20 };
			vec[1] = { 27,20 };
			vec[2] = { 27,-20};
			vec[3] = { -27,-20 };
			vec_count = 4;
			break;
		case Enemy7:
			vec[0] = { -32,13 };
			vec[1] = { 32,13};
			vec[2] = { 32,-13 };
			vec[3] = { -32,-13};
			vec_count = 4;
			break;
		case Enemy8:
			vec[0] = { -30,19 };
			vec[1] = { 30,19 };
			vec[2] = { 30,-19 };
			vec[3] = { -30,-19};
			vec_count = 4;
			break;	
		case Enemy9:
			vec[0] = { -40,22 };
			vec[1] = { 40,22 };
			vec[2] = { 40,-22 };
			vec[3] = { -40,-22 };
			vec_count = 4;
			break;
	    default:
		    break;
	}
	//��������ģ��
	auto enemyBody = PhysicsBody::create();
	enemyBody->addShape(PhysicsShapePolygon::create(vec, vec_count));
	enemyBody->setCategoryBitmask(GameScene::CategoryMaskBit::ENEMY_CATEGORYMASKBIT);
	enemyBody->setCollisionBitmask(0); //��������ײģ��,����Ҫ	
	enemyBody->setContactTestBitmask(GameScene::ContactMaskBit::ENEMY_CONTACTMASKBIT);
	enemyBody->setVelocity(Vect(0, m_enemyVec));
	this->setPhysicsBody(enemyBody);
	
	return true;
}
void PlaneEnemy::isCleanup(float dt)
{
	if (this->getPositionY() < (-this->getContentSize().height * 2))//�ɳ���Ļ���
	{
		this->stopAllActions();
		this->removeFromParent();
		return;
	}

	if (m_enemyLife <= 0)
	{
		//this->stopAllActions();
		this->blowUp();
		//log("remove enemy");
		return;
	}
}
void PlaneEnemy::onEnter()
{
	Sprite::onEnter();
	schedule(schedule_selector(PlaneEnemy::beginShoot2),0.8f);
	schedule(schedule_selector(PlaneEnemy::isCleanup),0.1f);

}

void PlaneEnemy::getHurt(int bulletPower)
{
	auto winSize = Director::getInstance()->getWinSize();
	if ((this->getPositionY()) > (winSize.height - this->getContentSize().height / 2))
		return;
	m_enemyLife-=bulletPower;
	//log("hurt");

}

void PlaneEnemy::beginShoot(float dt)
{
	auto winSize = Director::getInstance()->getWinSize();
	if (this->getPositionY() > winSize.height)
		return;

	//����һ���ӵ������뵽GameLayer���ӵ���Ⱦ����
	auto bullet = Sprite::createWithSpriteFrameName("blueBall2.png");
	bullet->setPosition(Vec2(this->getPosition().x, this->getPosition().y -0.5*this->getContentSize().height));
	GameScene::getBulletManager()->getBulletList()->addChild(bullet, 0, GameScene::ENEMY_BULLET_TAG);

	//���ӵ���һ��body����һ����ʼ�ٶȣ������䵽����������
	auto body = PhysicsBody::createBox(bullet->getContentSize(), PhysicsMaterial(10, 0, 0));
	body->setVelocity(Vect(0,m_enemyVec*2));
	body->setCategoryBitmask(GameScene::CategoryMaskBit::ENEMY_BULLET_CATEGORYMASKBIT);
	body->setContactTestBitmask(GameScene::ContactMaskBit::ENEMY_BULLET_CONTACTMASKBIT);
	body->setCollisionBitmask(0); //��������ײģ�⣬��Ϊ����Ҫ��
	bullet->setPhysicsBody(body);

}
void PlaneEnemy::beginShoot2(float dt)
{

	auto winSize = Director::getInstance()->getWinSize();
	if (this->getPositionY() > winSize.height)
		return;

	//����һ���ӵ������뵽GameLayer���ӵ���Ⱦ����
	auto bullet = Sprite::createWithSpriteFrameName("blueBall2.png");
	auto bulletSize = bullet->getContentSize();
	float ratio = 0.6;
	bullet->setScale(ratio);
	bullet->setContentSize(bulletSize*ratio);
	bullet->setPosition(Vec2(this->getPosition().x, this->getPosition().y - 0.5*this->getContentSize().height));
	GameScene::getBulletManager()->getBulletList()->addChild(bullet, 0, GameScene::ENEMY_BULLET_TAG);

	//���ӵ���һ��body����һ����ʼ�ٶȣ������䵽����������
	auto body = PhysicsBody::createBox(bullet->getContentSize(), PhysicsMaterial(10, 0, 0));
	body->setVelocity(Vect(0,-150));
	body->setCategoryBitmask(GameScene::CategoryMaskBit::ENEMY_BULLET_CATEGORYMASKBIT);
	body->setContactTestBitmask(GameScene::ContactMaskBit::ENEMY_BULLET_CONTACTMASKBIT);
	body->setCollisionBitmask(0); //��������ײģ�⣬��Ϊ����Ҫ��
	bullet->setPhysicsBody(body);
	auto dPos = bullet->getPosition() - PlaneHero::sharePosition();
	auto Dis = sqrt(dPos.x*dPos.x + dPos.y*dPos.y);
	auto action1 = MoveTo::create(Dis/100, PlaneHero::sharePosition());
	bullet->runAction(action1);
}
void PlaneEnemy::blowUp()
{
	this->getPhysicsBody()->removeFromWorld();     ////�����������ƿ�,�㲻�ᷢ������ģ����
	//this->getPhysicsBody()->setVelocity(Vec2(0, 0));//�ٶȲ�Ϊ���򶯻��޷�ִ��
	unscheduleAllSelectors();
	//unschedule(schedule_selector(PlaneHero::beginShooting));
	this->stopAllActions();
	auto animation = Animation::create();
	char str[64] = { 0 };
	for (int i = 1; i <= 35; i++)
	{
		sprintf(str, "explosion_%02d.png", i);
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(str));
		//log("%s", str);
	}
	animation->setDelayPerUnit(0.083);//��������֡����ʱ����
	animation->setLoops(1);//�����Ƿ�ѭ������,-1����ѭ��
	animation->setRestoreOriginalFrame(true);//���ö�����������Ƿ�ص���һ֡
	auto blowUp = Animate::create(animation);
	auto remove = CallFunc::create([this]() {this->removeFromParent(); });
	auto action = Sequence::create(blowUp, remove, nullptr);
	this->runAction(action);
	GameScene::getMessageManager()->addScore(m_enemyScore);
	SoundManager::playBlowUpSound();	
}