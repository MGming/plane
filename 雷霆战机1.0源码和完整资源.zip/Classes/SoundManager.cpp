#include"SoundManager.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;
using namespace CocosDenshion;
bool SoundManager::m_bgmSwitch= UserDefault::getInstance()->getBoolForKey("bgmSwitch");
bool SoundManager::m_effectSwitch = UserDefault::getInstance()->getBoolForKey("effectSwitch");
bool SoundManager::init()
{
	if (!Node::init())
	{
		return false;
	}

	if (UserDefault::getInstance()->getBoolForKey("isFileExit") != 1)
	{
		auto userdefault = UserDefault::getInstance();
		userdefault->setBoolForKey("isFileExit", 1);
		userdefault->setBoolForKey("bgmSwitch", 1);
		userdefault->setBoolForKey("effectSwitch", 1);
		userdefault->flush();	
	}

	m_bgmSwitch = UserDefault::getInstance()->getBoolForKey("bgmSwitch");
	m_effectSwitch = UserDefault::getInstance()->getBoolForKey("effectSwitch");
	return true;
}
void SoundManager::refresh()
{
	if (UserDefault::getInstance()->getBoolForKey("isFileExit") != 1)
	{
		auto userdefault = UserDefault::getInstance();
		userdefault->setBoolForKey("isFileExit", 1);
		userdefault->setBoolForKey("bgmSwitch", 1);
		userdefault->setBoolForKey("effectSwitch", 1);
		userdefault->flush();
	}

	m_bgmSwitch = UserDefault::getInstance()->getBoolForKey("bgmSwitch");
	m_effectSwitch = UserDefault::getInstance()->getBoolForKey("effectSwitch");
}
void SoundManager::playSureSound()
{
	if (m_effectSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("Sure.mp3");
}
void SoundManager::playMenuBgm()
{
	SimpleAudioEngine::getInstance()->stopBackgroundMusic(1);
	SimpleAudioEngine::getInstance()->stopAllEffects();
	if (m_bgmSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("Title.mp3",1);
	else
		SimpleAudioEngine::getInstance()->stopEffect(SimpleAudioEngine::getInstance()->playEffect("Title.mp3", true));
}
void SoundManager::playGameBgm()
{
	SimpleAudioEngine::getInstance()->stopEffect(SimpleAudioEngine::getInstance()->playEffect("Title.mp3", true));
	if (m_bgmSwitch == 1)
	{
		//���ű�������		
		SimpleAudioEngine::getInstance()->playBackgroundMusic("Stage1.mp3", true);
	}
}
void SoundManager::playPauseSound()
{
	SimpleAudioEngine::getInstance()->stopBackgroundMusic(1);
	SimpleAudioEngine::getInstance()->stopAllEffects();
	if (m_effectSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("pause.mp3");
}
void SoundManager::playCountdownSound()
{
	if (m_effectSwitch == 1)
	{
		SimpleAudioEngine::getInstance()->playEffect("Countdown.mp3");
	}
}
void SoundManager::playBlowUpSound()
{
	if (m_effectSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("Explosion.mp3");
}
void SoundManager::playGainGoldSound()
{
	if (m_effectSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("GainGold.mp3");
}
void SoundManager::playGainJewelSound()
{
	if (m_effectSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("GainJewel.mp3");
}
void SoundManager::playEntrySound()
{
	if (m_effectSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("Entry.mp3");
}
void SoundManager::playShootSound()
{
	if (m_effectSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("Shoot.mp3",true);
}
void SoundManager::playMissionStartSound()
{
	if (m_effectSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("MissionStart.mp3");
}
void SoundManager::playMissionCompleteSound()
{
	SimpleAudioEngine::getInstance()->stopBackgroundMusic(1);
	SimpleAudioEngine::getInstance()->stopAllEffects();
	if (m_effectSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("MissionComplete.mp3");
}
void SoundManager::playGameOverSound()
{
	SimpleAudioEngine::getInstance()->stopBackgroundMusic(1);
	SimpleAudioEngine::getInstance()->stopAllEffects();
	if (m_effectSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("GameOver.mp3");
}
void SoundManager::playBossBgm()
{
	SimpleAudioEngine::getInstance()->stopBackgroundMusic(1);
	if (m_bgmSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("Stage2.mp3",true);
}
void SoundManager::playWarningSound()
{
	SimpleAudioEngine::getInstance()->stopBackgroundMusic(1);
	if (m_effectSwitch == 1)
		SimpleAudioEngine::getInstance()->playEffect("Warning.mp3");
}