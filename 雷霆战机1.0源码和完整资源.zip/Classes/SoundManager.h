#pragma once
#include"cocos2d.h"
USING_NS_CC;
class SoundManager:public Node
{
private:
	bool isLive;
	static bool m_bgmSwitch;
	static bool m_effectSwitch;

public:
	bool init();
	static void refresh();        //���ص�ֵˢ�»�ȡ
	static void playSureSound();
	static void playMenuBgm();
	static void playGameBgm();
	static void playPauseSound();
	static void playCountdownSound();
	static void playBlowUpSound();
	static void playGainGoldSound();
	static void playGainJewelSound();
	static void playShootSound();
	static void playEntrySound();
	static void playMissionStartSound();
	static void playMissionCompleteSound();
	static void playGameOverSound();
	static void playBossBgm();
	static void playWarningSound();
	CREATE_FUNC(SoundManager);

};