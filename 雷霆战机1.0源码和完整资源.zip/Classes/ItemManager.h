#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class ItemManager :public cocos2d::Layer
{
public:
	bool init();
	//void removeBullet(float dt);
	SpriteBatchNode* getItemList() { return m_itemList; };
	void createItem(float dt);
	CREATE_FUNC(ItemManager);
private:
	SpriteBatchNode * m_itemList;

};
