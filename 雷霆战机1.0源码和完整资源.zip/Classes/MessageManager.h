#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class MessageManager:public cocos2d::Layer
{
private:
	 Layout* m_panel;
	 Button* m_pauseButton;
	 Text*   m_scoreText;
	 LoadingBar* m_bossPHBar;
	 Node* m_pauseLayer;
	 Layout* m_pausePanel;
	 Button* m_giveUpButton;
	 Button* m_continueButton;
	 Sprite* m_leftSprite;
	 Sprite* m_rightSprite;
	 Sprite* m_giveUpSprite;
	 Sprite* m_continueSprite;
	 Sprite* m_oneSprite;
	 Sprite* m_twoSprite;
	 Sprite* m_threeSprite;
	 Sprite* m_pauseSprite;
	 int m_score;
public:
	bool init();	
	void showScore(float dt);
	void showBossPH(float dt);
	void addScore(int score);
	LoadingBar* getBossPHBar() { return m_bossPHBar; }
	void pauseGame(cocos2d::Object* pSender, Widget::TouchEventType type);
	RenderTexture* getBgTexture();
	CREATE_FUNC(MessageManager);

};
