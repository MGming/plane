#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"GameScene.h"
#include"HeroManager.h"
#include"SoundManager.h"
#include"PlaneHero.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;

bool HeroManager::init()
{
	if (!Layer::init())
	{
		return false;
	}
	heroEntry();
	return true;
}
void HeroManager::onEnter()
{
	Layer::onEnter();	
}
void HeroManager::heroEntry()
{

	//�����ҷ��ɻ�
	auto planeHero = PlaneHero::create();
	planeHero->setAnchorPoint(Vec2(0.5, 0.5));
	planeHero->setPosition(Vec2(135, -50));
	this->addChild(planeHero, 1, GameScene::HERO_TAG);

	
	SoundManager::playEntrySound();
	
	auto func = CallFunc::create([this,planeHero]() {

		SoundManager::playMissionStartSound(); 
		//����󣬿�ʼ�����ӵ�,�ӵ��ٶȿɵ�
		planeHero->schedule(schedule_selector(PlaneHero::beginShooting), 0.3);
		SoundManager::playShootSound();

	});
	
	auto move = MoveTo::create(2.5, Vec2(135, 150));
	//auto dt = DelayTime::create(2.5);
	auto act = Sequence::create(move,func, nullptr);
	planeHero->runAction(act);
	
}