#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"BulletManager.h"
#include"ItemManager.h"
#include"EnemyManager.h"
#include"MessageManager.h"
#include"HeroManager.h"
USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class GameScene : public cocos2d::Layer
{
private:
	static GameScene* m_gameLayer;                //��Ϸ������������
    static BulletManager* m_bulletManager;        //�ӵ�������
	static ItemManager*  m_itemManager;           //��Ʒ������
	static EnemyManager*  m_enemyManager;         //�л�������
	static MessageManager * m_messageManager;     //��Ϣ������
	static HeroManager* m_heroManager;            //�ҷ�ս��������
	
public:
	
	static cocos2d::Scene* createScene();
    virtual bool init();
    CREATE_FUNC(GameScene);
	
	void addPlaneControl();
	static GameScene* sharedGameLayer() { return m_gameLayer; }
	void playMap();
	bool dealWithContact(PhysicsContact& contact);
	void gameOver();
	void gameVictory();


	static BulletManager* getBulletManager() { return m_bulletManager; }
	static ItemManager* getItemManager() { return m_itemManager; }
	static EnemyManager* getEnemyManager() { return m_enemyManager; }
	static MessageManager* getMessageManager() { return m_messageManager; }
	static HeroManager* getHeroManager() { return m_heroManager; }

public:
	enum NodeTag
	{   
		ROOTNODE_TAG=100,
		HERO_TAG = 101,
	    ENEMY_TAG = 102,
		HERO_BULLET_TAG=103,
		ENEMY_BULLET_TAG = 104,
		ITEM_TAG=105,
		BOSS_TAG=106,
		MISSILE=110

	};
	//�����������
	enum CategoryMaskBit
	{
		HERO_CATEGORYMASKBIT =16,             //10000
		HERO_BULLET_CATEGORYMASKBIT =8,       //01000
		ENEMY_CATEGORYMASKBIT =1,             //00001
		ENEMY_BULLET_CATEGORYMASKBIT =2,      //00010
		ITEM_CATEGORYMASKBIT =4,              //00100
	};
	//���Ա���Щ�������������֪ͨ�¼�������bitλ
	enum ContactMaskBit
	{   
		ENEMY_CONTACTMASKBIT = 24,            //11000
		ENEMY_BULLET_CONTACTMASKBIT=24,       //11000
		HERO_BULLET_CONTACTMASKBIT = 3,       //00011
		HERO_CONTACTMASKBIT = 7,              //00111
		ITEM_CONTACTMASKBIT = 16              //10000
	};
	

};
