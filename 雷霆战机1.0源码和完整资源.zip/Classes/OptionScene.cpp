#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"GameMenu.h"
#include"OptionScene.h"
#include"SoundManager.h"



USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;

Scene* OptionScene::createScene()
{
	auto scene = Scene::create();
	auto layer = OptionScene::create();
	scene->addChild(layer);
	return scene;
}
bool OptionScene::init()
{
	if (!Layer::init())
	{
		return false;
	}
	auto winSize = Director::getInstance()->getWinSize();

	auto optionLayer = CSLoader::createNode("OptionScene.csb");
	optionLayer->setAnchorPoint(Vec2(0, 0));
	optionLayer->setPosition(Vec2(0, 0));
	this->addChild(optionLayer);

	//��ȡ��ť
	m_panel = (Layout*)optionLayer->getChildByName("Panel");
	m_backButton = (Button*)Helper::seekWidgetByName(m_panel, "BackButton");
	m_aboutButton = (Button*)Helper::seekWidgetByName(m_panel, "AboutButton");
	m_helpButton = (Button*)Helper::seekWidgetByName(m_panel, "HelpButton");
	m_bgmCheckBox = (CheckBox*)Helper::seekWidgetByName(m_panel, "BgmCheckBox");
	m_effectCheckBox = (CheckBox*)Helper::seekWidgetByName(m_panel, "EffectCheckBox");

	//���¼�
	m_backButton->addTouchEventListener(CC_CALLBACK_2(OptionScene::back, this));
	m_bgmCheckBox->addEventListener(CC_CALLBACK_2(OptionScene::bgmSwitch, this));
	m_effectCheckBox->addEventListener(CC_CALLBACK_2(OptionScene::effectSwitch, this));
	m_aboutButton->addTouchEventListener(CC_CALLBACK_2(OptionScene::about, this));

    //����ҳ��ͼ��
	m_aboutLayer = CSLoader::createNode("AboutLayer.csb");
	m_aboutLayer->setAnchorPoint(Vec2(0.5, 0.5));
	m_aboutLayer->setPosition(Vec2(winSize.width / 2, winSize.height / 2));
	m_panel->addChild(m_aboutLayer);
	m_aboutLayer->setVisible(0);
	//��ȡ��ť
	m_aboutPanel = (Layout*)m_aboutLayer->getChildByName("Panel");
	m_backButton_about = (Button*)Helper::seekWidgetByName(m_aboutPanel, "BackButton_about");
	//���¼�
	m_backButton_about->addTouchEventListener(CC_CALLBACK_2(OptionScene::back_about, this));

	//��ȡ��ѡ��ť״̬
	m_bgmSwitch = UserDefault::getInstance()->getBoolForKey("bgmSwitch");
	m_effectSwitch = UserDefault::getInstance()->getBoolForKey("effectSwitch");
	m_bgmCheckBox->setSelectedState(m_bgmSwitch);
	m_effectCheckBox->setSelectedState(m_effectSwitch);

	return true;
}
void OptionScene::back(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		SoundManager::playSureSound();
		Director::getInstance()->replaceScene(TransitionFade::create(0.1f,GameMenu::createScene()));
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}
}
void OptionScene::bgmSwitch(cocos2d::Object* pSender, CheckBox::EventType type)
{
	switch (type)
	{

	case CheckBox::EventType::SELECTED:
		UserDefault::getInstance()->setBoolForKey("bgmSwitch", 1);
		UserDefault::getInstance()->flush();
		SoundManager::refresh();
		SoundManager::playSureSound();
		SoundManager::playMenuBgm();
		 //log("bgmSelect");
		break;

	case CheckBox::EventType::UNSELECTED:
		UserDefault::getInstance()->setBoolForKey("bgmSwitch", 0);
		UserDefault::getInstance()->flush();
		SoundManager::refresh();
		SoundManager::playSureSound();
		SoundManager::playMenuBgm();
		//log("bgmUnselect");
		break;
	}
}
void OptionScene::effectSwitch(cocos2d::Object* pSender, CheckBox::EventType type)
{
	switch (type)
	{

	case CheckBox::EventType::SELECTED:
		UserDefault::getInstance()->setBoolForKey("effectSwitch", 1);
		UserDefault::getInstance()->flush();
		SoundManager::refresh();
		SoundManager::playSureSound();
		//log("effectSelect");
		break;

	case CheckBox::EventType::UNSELECTED:
		UserDefault::getInstance()->setBoolForKey("effectSwitch", 0);
		UserDefault::getInstance()->flush();
		SoundManager::refresh();
		//log("effectUnselect");
		break;
	}
}
void OptionScene::about(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		SoundManager::playSureSound();
		m_aboutLayer->setVisible(1);
		m_aboutLayer->setScale(0.4);
		m_aboutLayer->runAction(ScaleTo::create(0.25, 1));
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}
}
void OptionScene::back_about(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		SoundManager::playSureSound();
		m_aboutLayer->setVisible(0);
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}
}