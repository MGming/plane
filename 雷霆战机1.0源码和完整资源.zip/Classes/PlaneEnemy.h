#pragma once
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class PlaneEnemy :public Sprite
{
 public:
	 enum EnemyType
	 {
	    Enemy1,
		Enemy2,
		Enemy3,
		Enemy4,//��������ս��
		Enemy5,
		Enemy6,
		Enemy7,
		Enemy8,
		Enemy9
	 };
	 enum EnemyLife
	 {
		 Enemy1_Life = 1,
		 Enemy2_Life = 3,
		 Enemy3_Life = 5,
		 Enemy4_Life = 8,
		 Enemy5_Life = 10,
		 Enemy6_Life = 12,
		 Enemy7_Life = 14,
		 Enemy8_Life = 16,
		 Enemy9_Life = 18
	 };
	 enum EnemyVec
	 {
		 Enemy1_Vec=-150,
		 Enemy2_Vec=-100,
		 Enemy3_Vec=-80,
		 Enemy4_Vec=-80
	 };
	 enum EnemyScore
	 {
		 Enemy1_Score = 5,
		 Enemy2_Score = 10,
		 Enemy3_Score = 15,
		 Enemy4_Score = 30,
		 Enemy5_Score = 40,
		 Enemy6_Score = 60,
		 Enemy7_Score = 70,
		 Enemy8_Score = 80,
		 Enemy9_Score = 100,
	 };
private:
	int m_enemyLife;
	int m_enemyVec;
	int m_enemyType;
	bool m_live;
	int m_enemyScore;

public:
	static PlaneEnemy* createWithEnemyType(int enemyType);
	bool init(int enemyType);
	void onEnter();
	void isCleanup(float dt);
	void getHurt(int bulletPower);
	void beginShoot(float dt);
	void beginShoot2(float dt);
	void blowUp();
	int getEnemyScore() { return m_enemyScore; };
};