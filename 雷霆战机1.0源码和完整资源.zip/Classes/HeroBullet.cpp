#include"HeroBullet.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"GameScene.h"
USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;

HeroBullet* HeroBullet::createWithBulletType(float v,int p,int t)
{
	HeroBullet* bullet = new HeroBullet();
	if (bullet&&bullet->init(v,p,t))
	{
		bullet->autorelease();
		return bullet;
	}
	else
	{
		CC_SAFE_DELETE(bullet);
		return nullptr;
	}

}


bool HeroBullet::init(float v,int p,int t)
{
	if (!Sprite::init())
	{
		return false;
	}
	this->initWithSpriteFrameName("orangeCircle.png");
	this->m_bulletVec = v;
	this->m_bulletPower = p;
	this->m_bulletType = t;

	//�����ӵ��Ĵ�С,ʹ��С������������
	float ratio;
	switch(m_bulletPower)
	{
	case 1:
		   this->setScale(0.6);
		   ratio = 0.6;
		   break;
	case 2:
		this->setScale(0.8);
		ratio = 0.8;
		break;
	case 3:
		this->setScale(1.0);
		ratio =1.0;
		break;
	default:
		this->setScale(1.0);
		ratio = 1.0;
		break;

	}



	//���ӵ���һ��body����һ����ʼ�ٶȣ������䵽����������
	auto body = PhysicsBody::createBox(this->getContentSize()*ratio, PhysicsMaterial(10, 0, 0));
	body->setVelocity(Vect(0,400));
	body->setCategoryBitmask(GameScene::CategoryMaskBit::HERO_BULLET_CATEGORYMASKBIT);
	body->setContactTestBitmask(GameScene::ContactMaskBit::HERO_BULLET_CONTACTMASKBIT);
	body->setCollisionBitmask(0); //��������ײģ�⣬��Ϊ����Ҫ��
	this->setPhysicsBody(body);

	return true;
}