#pragma once
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class Item :public Sprite
{
public:
	enum ItemType
	{
		AMETHYST,
		RUBY,
		SAPPHIRE,
		GOLD
	};
	struct BuffStruct
	{
		int v;//�����ٶȼӳ�
		int p;//�ӵ������ӳ�
		int n;//�ӵ������ӳ�
		int s;//�����ӳ�
	}buff;

public:	
	static Item* createWithItemType(int itemType);
	bool init(int itemType);
	void randomMove(float dt);
	struct BuffStruct* getBuff(){ return &buff; }


private:

	int m_itemType;
	int m_isLive;
	void onEnter();



};