#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"ItemManager.h"
#include"Item.h"
#include"GameScene.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

bool ItemManager::init()
{
	if (!Layer::init())
	{
		return false;
    }

	m_itemList = SpriteBatchNode::create("Item.png");
	this->addChild(m_itemList, 0);

	//��������
	schedule(schedule_selector(ItemManager::createItem), 10);

	return true;
}


void ItemManager::createItem(float dt)
{
	if (m_itemList->getChildrenCount()>= 2)//����һ���Գ�����������2������
		return;
	int type = random(0, 3);
	//��������
	auto item = Item::createWithItemType(type);
	item->setPosition(Vec2(0, 800));
	m_itemList->addChild(item, 1, GameScene::ITEM_TAG);
}
