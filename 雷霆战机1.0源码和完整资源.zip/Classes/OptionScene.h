#pragma once
#pragma 
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"BulletManager.h"
#include"ItemManager.h"
#include"EnemyManager.h"
#include"MessageManager.h"
USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
class OptionScene :public Layer
{
private:
	Layout* m_panel;
	Button* m_backButton;
	Button* m_aboutButton;
	Button* m_helpButton;
	CheckBox* m_bgmCheckBox;
	CheckBox* m_effectCheckBox;
	Node* m_aboutLayer;
	Layout* m_aboutPanel;
	Button* m_backButton_about;
	bool m_bgmSwitch;
	bool m_effectSwitch;
public:
	static Scene* createScene();
	bool init();
	CREATE_FUNC(OptionScene);
	void back(cocos2d::Object* pSender, Widget::TouchEventType type);
	void about(cocos2d::Object* pSender, Widget::TouchEventType type);
	void bgmSwitch(cocos2d::Object* pSender, CheckBox::EventType type);
	void effectSwitch(cocos2d::Object* pSender, CheckBox::EventType type);
	void back_about(cocos2d::Object* pSender, Widget::TouchEventType type);



};
