#include"Item.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"GameScene.h"
USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;

Item* Item::createWithItemType(int itemType)
{
	Item* item = new Item();
	if (item&&item->init(itemType))
	{
		item->autorelease();
		return item;
	}
	else
	{
		CC_SAFE_DELETE(item);
		return nullptr;
	}

}

bool Item::init(int itemType)
{
	if (!Sprite::init())
	{
		return false;
	}
	this->m_itemType = itemType;
	this->m_isLive = 1;
	String itemName;
	auto animation = Animation::create();
	switch (itemType)
	{
	case AMETHYST:
		itemName = "Amethyst_01.png";//��ɫ
		this->setName("Amethyst");
		buff.v = 0;
		buff.p = 0;
		buff.n = 1;
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Amethyst_01.png"));
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Amethyst_02.png"));
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Amethyst_03.png"));
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Amethyst_04.png"));
		break;
	case RUBY:
		itemName = "Ruby_01.png";//��ɫ
		this->setName("Ruby");
		buff.v = 0;
		buff.p = 1;
		buff.n = 0;
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Ruby_01.png"));
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Ruby_02.png"));
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Ruby_03.png"));
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Ruby_04.png"));
		break;
	case SAPPHIRE:
		itemName = "Sapphire_01.png";//��ɫ
		this->setName("Sapphire");
		buff.v = 1;
		buff.p = 0;
		buff.n = 0;
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Sapphire_01.png"));
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Sapphire_02.png"));
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Sapphire_03.png"));
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Sapphire_04.png"));
		break;
	case GOLD:
		itemName = "Gold_01.png";
		this->setName("Gold");
		buff.v = 0;
		buff.p = 0;
		buff.n = 0;
		buff.s = 500;
		break;
	default:
		break;			
	}
	this->initWithSpriteFrameName(itemName.getCString());
	animation->setDelayPerUnit(0.1);//��������֡����ʱ����
	animation->setLoops(-1);//�����Ƿ�ѭ������,-1����ѭ��,����n����n��,0������
	animation->setRestoreOriginalFrame(true);//���ö�����������Ƿ�ص���һ֡
	auto fly = Animate::create(animation);
	this->runAction(fly);
	this->setUserData(&buff);
	return true;
}
void Item::randomMove(float dt)
{
	auto winSize = Director::getInstance()->getWinSize();
	auto itemSize = this->getContentSize();
	float x, y, fDist;
	do
	{
		x = rand()%(int)winSize.width;
		y = rand() % (int)winSize.height;
		fDist = sqrt(pow(x - (this->getPositionX()), 2) + pow(y - (this->getPositionY()), 2));

	} while (fDist<50);
	this->stopActionByTag(100);
	auto move = MoveTo::create(fDist / 50, Vec2(x, y));
	move->setTag(100);
	this->runAction(move);

	//��������һ��body����һ����ʼ�ٶȣ������䵽����������
	auto body = PhysicsBody::createBox(this->getContentSize(), PhysicsMaterial(0, 0, 0));
	body->setVelocity(Vect(0,0));
	body->setCategoryBitmask(GameScene::CategoryMaskBit::ITEM_CATEGORYMASKBIT);
	body->setContactTestBitmask(GameScene::ContactMaskBit::ITEM_CONTACTMASKBIT);
	body->setCollisionBitmask(0); //��������ײģ�⣬��Ϊ����Ҫ��
	this->setPhysicsBody(body);

}
void Item::onEnter()
{
	Sprite::onEnter();
	schedule(schedule_selector(Item::randomMove), 1.0);


}