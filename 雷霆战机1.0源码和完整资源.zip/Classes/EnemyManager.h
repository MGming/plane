#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class EnemyManager :public cocos2d::Layer
{
public:
	bool init();
	Node* getEnemyList() { return m_enemyList; };
	void addEnemyPlanes_1(float dt);
	void addEnemyPlanes_2(float dt);
	void addEnemyPlanes_3(float dt);
	void addEnemyPlanes_4(float dt);
	void addEnemyPlanes_5(float dt);
	void addEnemyPlanes_6(float dt);
	void addEnemyPlanes_7(float dt);
	void addEnemyPlanes_8(float dt);
	void addEnemyPlanes_9(float dt);//��9��ʼ������ս��
	void addEnemyPlanes_10(float dt);
	void addEnemyPlanes_11(float dt);
	void addEnemyPlanes_12(float dt);
	void addEnemyPlanes_13(float dt);
	void addBoss(float dt);
	void addEnemys(float dt);
	CREATE_FUNC(EnemyManager);
private:
	Node * m_enemyList;
	int  m_time;            //���ڼ�¼���ӵл��Ĵ���

};