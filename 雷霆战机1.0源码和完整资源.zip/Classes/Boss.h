#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class Boss :public cocos2d::Sprite
{
public:
	CREATE_FUNC(Boss);
	bool init();
	void onEnter();
	void randomMove(float dt);
	void beginShooting(float dt);
	void isCleanup(float dt);
	void getHurt(int bulletPower);
	void shoot1();
	void shoot2();
	void shoot3();
	void blowUp(); //�ɻ���ը
	bool isLive();
	


private:
	int m_enemyLife;
	int m_bulletType;//����	
	float m_bulletVec;//�ٶ�
	int m_bulletPower;//����
	int m_bulletNumber;//����
	int m_enemyScore;  //����


};
