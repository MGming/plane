#pragma once
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class HeroManager :public Layer
{
public:
	bool init();
	void heroEntry();
	void onEnter();
	CREATE_FUNC(HeroManager);


};
