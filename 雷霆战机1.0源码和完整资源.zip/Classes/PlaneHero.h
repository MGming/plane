#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"Item.h";

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class PlaneHero:public cocos2d::Sprite
{

private:
	int m_heroLife;
	static Vec2 heroPos;
	int m_bulletType;//����	
	float m_bulletVec;//�ٶ�
	int m_bulletPower;//����
	int m_bulletNumber;//����

public:
	CREATE_FUNC(PlaneHero);
	bool init();
	void onEnter();
	bool isLive();
	void beginShooting(float dt);
	void getItem(Item* item);
	static Vec2 sharePosition();
	void updatePosition(float dt);
	void getHurt(int bulletPower);
	void blowUp();                 //�ɻ���ը
	void isCleanup(float dt);

};
