#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"PauseScene.h"
#include"SoundManager.h"
#include"GameMenu.h"
#include "GameScene.h"





USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;

Scene* PauseScene::createScene(RenderTexture* tex)
{
	auto scene = Scene::create();
	auto layer = PauseScene::create();
	scene->addChild(layer);
	auto bgTex = tex->getSprite()->getTexture();
	auto bgSprite = Sprite::createWithTexture(bgTex);
	bgSprite->setFlipY(true);
	bgSprite->setAnchorPoint(Vec2(0, 0));
	layer->addChild(bgSprite, 0);

	return scene;
}
bool PauseScene::init()
{
	if (!Layer::init())
	{
		return false;
	}


	//��ͣҳ��ͼ��
	m_pauseLayer = CSLoader::createNode("PauseLayer.csb");
	m_pauseLayer->setAnchorPoint(Vec2(0, 0));
	m_pauseLayer->setPosition(Vec2(0, 0));
	this->addChild(m_pauseLayer,1);
	m_pauseLayer->setVisible(0);

	//��ȡ��ť
	m_pausePanel = (Layout*)m_pauseLayer->getChildByName("Panel");
	//m_giveUpButton= (Button*)Helper::seekWidgetByName(m_pausePanel, "GiveUpButton");//���ַ�ʽҲֻ�ܵõ��ӽڵ�,���ܵõ��ӽڵ����µĽڵ�
	//m_continueButton = (Button*)Helper::seekWidgetByName(m_pausePanel, "ContinueButton");
	m_giveUpSprite = (Sprite*)m_pausePanel->getChildByName("GiveUpSprite");
	m_continueSprite = (Sprite*)m_pausePanel->getChildByName("ContinueSprite");
	m_leftSprite = (Sprite*)m_pausePanel->getChildByName("LeftSprite");
	m_rightSprite = (Sprite*)m_pausePanel->getChildByName("RightSprite");
	m_oneSprite = (Sprite*)m_pausePanel->getChildByName("OneSprite");
	m_twoSprite = (Sprite*)m_pausePanel->getChildByName("TwoSprite");
	m_threeSprite = (Sprite*)m_pausePanel->getChildByName("ThreeSprite");
	m_pauseSprite = (Sprite*)m_pausePanel->getChildByName("PauseSprite");
	m_giveUpButton = (Button*)m_giveUpSprite->getChildByName("GiveUpButton");
	m_continueButton = (Button*)m_continueSprite->getChildByName("ContinueButton");

	//���¼�
	m_giveUpButton->addTouchEventListener(CC_CALLBACK_2(PauseScene::giveUpGame, this));
	m_continueButton->addTouchEventListener(CC_CALLBACK_2(PauseScene::continueGame, this));

	//123��ͣͼ�겻�ɼ�
	m_oneSprite->setVisible(0);
	m_twoSprite->setVisible(0);
	m_threeSprite->setVisible(0);
	m_pauseSprite->setVisible(0);

	//��ͣ������Ч
	m_pauseLayer->setVisible(1);
	this->runAction(Sequence::create(DelayTime::create(0.55), CallFunc::create([this]() {m_pauseSprite->setVisible(1); }), nullptr));
	m_giveUpSprite->runAction(MoveBy::create(0.5, Vec2(100, 0)));
	m_continueSprite->runAction(MoveBy::create(0.5, Vec2(-100, 0)));
	m_leftSprite->runAction(MoveBy::create(0.5, Vec2(180, 0)));
	m_rightSprite->runAction(MoveBy::create(0.5, Vec2(-180, 0)));

	return true;
}

void PauseScene::continueGame(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		m_giveUpSprite->runAction(MoveBy::create(0.5, Vec2(-100, 0)));
		m_continueSprite->runAction(MoveBy::create(0.5, Vec2(100, 0)));	
		countdown();
		//log("continue");
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}
}
void PauseScene::giveUpGame(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		//log("giveUp");
		Director::getInstance()->purgeCachedData();//Ϊ�˷�ֹ�ڴ�й©
		Director::getInstance()->popToRootScene();//Ϊ�˷�ֹ�ڴ�й©
		Director::getInstance()->replaceScene(TransitionFade::create(0.1f, GameMenu::createScene()));
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}
}
void PauseScene::countdown()
{
	auto func3_0 = CallFunc::create([this]() {m_threeSprite->setVisible(0); });
	auto func2_0 = CallFunc::create([this]() {m_twoSprite->setVisible(0); });
	auto func1_0 = CallFunc::create([this]() {m_oneSprite->setVisible(0); });
	auto func3_1 = CallFunc::create([this]() {m_threeSprite->setVisible(1); });
	auto func2_1 = CallFunc::create([this]() {m_twoSprite->setVisible(1); });
	auto func1_1 = CallFunc::create([this]() {m_oneSprite->setVisible(1); });
	auto funcPause_0 = CallFunc::create([this]() {m_pauseSprite->setVisible(0); });
	auto funcPause_1 = CallFunc::create([this]() {m_pauseSprite->setVisible(1); });
	auto funcLayer_0 = CallFunc::create([this]() {m_pauseLayer->setVisible(0); Director::getInstance()->popScene(); SoundManager::playGameBgm();});
	auto dt = DelayTime::create(1.0);
	auto dt2 = DelayTime::create(0.5);

	auto funcLeft_0 = CallFunc::create([this]() {m_leftSprite->runAction(MoveBy::create(0.5, Vec2(-180, 0))); });
	auto funcRight_0 = CallFunc::create([this]() {m_rightSprite->runAction(MoveBy::create(0.5, Vec2(180, 0))); });
	auto move = Spawn::create(funcLeft_0, funcRight_0, nullptr);
	auto shootSound_1 = CallFunc::create([this]() {SoundManager::playShootSound(); });
	auto countdowmActtion = Sequence::create(funcPause_0, func3_1, dt, func3_0, func2_1, dt, func2_0, func1_1, dt, func1_0, move, dt2, funcLayer_0, shootSound_1, nullptr);

	SoundManager::playCountdownSound();
	this->runAction(countdowmActtion);

}