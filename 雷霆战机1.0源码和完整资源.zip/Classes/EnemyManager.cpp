#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include"EnemyManager.h"
#include"GameScene.h"
#include"PlaneEnemy.h"
#include"Boss.h"
#include"SoundManager.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

bool EnemyManager::init()
{
	if (!Layer::init())
	{
		return false;
	}

	m_enemyList =Node::create();
	this->addChild(m_enemyList, 0);
	this->m_time = 1;

	scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_1), 6);
	scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_2), 8);
	scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_3), 12);
	scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_4), 19);
	scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_5), 25);
	scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_6), 30);
	scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_7), 35);
	scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_8), 39);
	schedule(schedule_selector(EnemyManager::addEnemys),3,1000,43);

	//scheduleOnce(schedule_selector(EnemyManager::addBoss),1);
	return true;
}
void EnemyManager::addBoss(float dt)
{
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	auto addFunc=CallFunc::create([this,X,Y](){
		auto boss = Boss::create();
	    boss->setPosition(Vec2(X / 2, Y*0.8));
	    m_enemyList->addChild(boss, 1, GameScene::BOSS_TAG);
	});
	auto soundFunc = CallFunc::create([](){
		SoundManager::playWarningSound();
	});
	auto dtime = DelayTime::create(3);
	auto act = Sequence::create(soundFunc, dtime, addFunc, nullptr);
	this->runAction(act);
}
void EnemyManager::addEnemyPlanes_1(float dt)
{
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	int enemyType = PlaneEnemy::Enemy1;

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(enemyType);	
	enemyPlane1->setPosition(Vec2(winSize.width/2, winSize.height +100));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane2->setPosition(Vec2(winSize.width / 2-X*0.2, winSize.height + 200));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane3->setPosition(Vec2(winSize.width / 2+X*0.2, winSize.height + 200));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);
	

}
void EnemyManager::addEnemyPlanes_2(float dt)
{

	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	int enemyType = PlaneEnemy::Enemy2;

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane1->setPosition(Vec2(winSize.width / 2-X*0.4, winSize.height + 200));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane2->setPosition(Vec2(winSize.width / 2-X*0.2, winSize.height + 100));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane3->setPosition(Vec2(winSize.width / 2+X*0.2, winSize.height + 100));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);

	auto enemyPlane4 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane4->setPosition(Vec2(winSize.width / 2 +X*0.4, winSize.height + 200));
	m_enemyList->addChild(enemyPlane4, 1, GameScene::ENEMY_TAG);
}
void EnemyManager::addEnemyPlanes_3(float dt)
{
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	int enemyType = PlaneEnemy::Enemy3;

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane1->setPosition(Vec2(winSize.width / 2 - X * 0.4, winSize.height ));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane2->setPosition(Vec2(winSize.width / 2 - X * 0.2, winSize.height +80));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane3->setPosition(Vec2(winSize.width / 2, winSize.height + 160));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);

	auto enemyPlane4 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane4->setPosition(Vec2(winSize.width / 2 + X * 0.2, winSize.height + 240));
	m_enemyList->addChild(enemyPlane4, 1, GameScene::ENEMY_TAG);


}
void EnemyManager::addEnemyPlanes_4(float dt)
{
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	int enemyType = PlaneEnemy::Enemy3;

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(0);
	enemyPlane1->setPosition(Vec2(X*0.2, winSize.height+150));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(0);
	enemyPlane2->setPosition(Vec2(X*0.8, winSize.height + 150));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(1);
	enemyPlane3->setPosition(Vec2(X*0.35, winSize.height + 80));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);

	auto enemyPlane4 = PlaneEnemy::createWithEnemyType(1);
	enemyPlane4->setPosition(Vec2(X*0.35, winSize.height + 300));
	m_enemyList->addChild(enemyPlane4, 1, GameScene::ENEMY_TAG);

	auto enemyPlane5 = PlaneEnemy::createWithEnemyType(1);
	enemyPlane5->setPosition(Vec2(X * 0.65, winSize.height + 80));
	m_enemyList->addChild(enemyPlane5, 1, GameScene::ENEMY_TAG);

	auto enemyPlane6 = PlaneEnemy::createWithEnemyType(1);
	enemyPlane6->setPosition(Vec2(X * 0.65, winSize.height + 300));
	m_enemyList->addChild(enemyPlane6, 1, GameScene::ENEMY_TAG);

	auto enemyPlane7 = PlaneEnemy::createWithEnemyType(2);
	enemyPlane7->setPosition(Vec2(X * 0.5, winSize.height + 340));
	m_enemyList->addChild(enemyPlane7, 1, GameScene::ENEMY_TAG);

}
void EnemyManager::addEnemyPlanes_5(float dt)
{
	//ͬ2
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	int enemyType = PlaneEnemy::Enemy2;

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane1->setPosition(Vec2(winSize.width / 2 - X * 0.4, winSize.height + 200));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane2->setPosition(Vec2(winSize.width / 2 - X * 0.2, winSize.height + 100));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane3->setPosition(Vec2(winSize.width / 2 + X * 0.2, winSize.height + 100));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);

	auto enemyPlane4 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane4->setPosition(Vec2(winSize.width / 2 + X * 0.4, winSize.height + 200));
	m_enemyList->addChild(enemyPlane4, 1, GameScene::ENEMY_TAG);
}
void EnemyManager::addEnemyPlanes_6(float dt)
{    //ͬ3
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	int enemyType = PlaneEnemy::Enemy3;

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane1->setPosition(Vec2(winSize.width / 2 - X * 0.4, winSize.height));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane2->setPosition(Vec2(winSize.width / 2 - X * 0.2, winSize.height + 80));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane3->setPosition(Vec2(winSize.width / 2, winSize.height + 160));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);

	auto enemyPlane4 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane4->setPosition(Vec2(winSize.width / 2 + X * 0.2, winSize.height + 240));
	m_enemyList->addChild(enemyPlane4, 1, GameScene::ENEMY_TAG);


}
void EnemyManager::addEnemyPlanes_7(float dt)
{   //ͬ4
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	int enemyType = PlaneEnemy::Enemy3;

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(0);
	enemyPlane1->setPosition(Vec2(X*0.2, winSize.height + 150));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(0);
	enemyPlane2->setPosition(Vec2(X*0.8, winSize.height + 150));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(1);
	enemyPlane3->setPosition(Vec2(X*0.35, winSize.height + 80));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);

	auto enemyPlane4 = PlaneEnemy::createWithEnemyType(1);
	enemyPlane4->setPosition(Vec2(X*0.35, winSize.height + 300));
	m_enemyList->addChild(enemyPlane4, 1, GameScene::ENEMY_TAG);

	auto enemyPlane5 = PlaneEnemy::createWithEnemyType(1);
	enemyPlane5->setPosition(Vec2(X * 0.65, winSize.height + 80));
	m_enemyList->addChild(enemyPlane5, 1, GameScene::ENEMY_TAG);

	auto enemyPlane6 = PlaneEnemy::createWithEnemyType(1);
	enemyPlane6->setPosition(Vec2(X * 0.65, winSize.height + 300));
	m_enemyList->addChild(enemyPlane6, 1, GameScene::ENEMY_TAG);

	auto enemyPlane7 = PlaneEnemy::createWithEnemyType(2);
	enemyPlane7->setPosition(Vec2(X * 0.5, winSize.height + 340));
	m_enemyList->addChild(enemyPlane7, 1, GameScene::ENEMY_TAG);

}
void EnemyManager::addEnemyPlanes_8(float dt)
{   
	//ͬ1
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	int enemyType = PlaneEnemy::Enemy1;

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane1->setPosition(Vec2(winSize.width / 2, winSize.height + 100));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane2->setPosition(Vec2(winSize.width / 2 - X * 0.2, winSize.height + 200));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane3->setPosition(Vec2(winSize.width / 2 + X * 0.2, winSize.height + 200));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);


}
void EnemyManager::addEnemyPlanes_9(float dt)
{
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	int enemyType = PlaneEnemy::Enemy4;

	auto action1 = MoveBy::create(4, Vec2(X*0.4,-300));
	auto action2 = MoveBy::create(4, Vec2(X*0.4, -300));
	auto action3 = MoveBy::create(4, Vec2(-X*0.4, -300));
	auto action4 = MoveBy::create(4, Vec2(-X * 0.4, -300));
	
	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(4);
	enemyPlane1->setPosition(Vec2(X*0.2, winSize.height + 200));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);
	enemyPlane1->runAction(action1);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane2->setPosition(Vec2(X*0.4, winSize.height + 100));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);
	enemyPlane2->runAction(action2);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(4);
	enemyPlane3->setPosition(Vec2(X*0.8, winSize.height + 200));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);
	enemyPlane3->runAction(action3);

	auto enemyPlane4 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane4->setPosition(Vec2(X*0.6, winSize.height + 100));
	m_enemyList->addChild(enemyPlane4, 1, GameScene::ENEMY_TAG);
	enemyPlane4->runAction(action4);


}
void EnemyManager::addEnemyPlanes_10(float dt)
{
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	int enemyType = PlaneEnemy::Enemy6;

	auto action1 = MoveBy::create(3, Vec2(0, -0.4*Y));
	auto action2 = MoveBy::create(3, Vec2(0, -0.4*Y));
	auto action3 = MoveBy::create(3, Vec2(0, -0.4*Y));
	auto action4 = MoveBy::create(3, Vec2(0, -0.4*Y));

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(6);
	enemyPlane1->setPosition(Vec2(X*0.2, winSize.height + 150));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);
	enemyPlane1->runAction(action1);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane2->setPosition(Vec2(X*0.4, winSize.height + 100));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);
	enemyPlane2->runAction(action2);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(6);
	enemyPlane3->setPosition(Vec2(X*0.8, winSize.height + 150));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);
	enemyPlane3->runAction(action3);

	auto enemyPlane4 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane4->setPosition(Vec2(X*0.6, winSize.height + 100));
	m_enemyList->addChild(enemyPlane4, 1, GameScene::ENEMY_TAG);
	enemyPlane4->runAction(action4);

}
void EnemyManager::addEnemyPlanes_11(float dt)
{
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	int enemyType = PlaneEnemy::Enemy7;

	auto action1 = MoveTo::create(3, Vec2(X*0.2, Y*0.6));
	auto action2 = MoveTo::create(3, Vec2(X*0.35, 0.7*Y));
	auto action3 = MoveTo::create(3, Vec2(X*0.8, Y*0.6));
	auto action4 = MoveTo::create(3, Vec2(X*0.65, 0.7*Y));
	auto action5 = MoveBy::create(3, Vec2(0, -0.45*Y));

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(7);
	enemyPlane1->setPosition(Vec2(-50, 150));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);
	enemyPlane1->runAction(action1);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane2->setPosition(Vec2(-50, 250));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);
	enemyPlane2->runAction(action2);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(7);
	enemyPlane3->setPosition(Vec2(X+50, 150));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);
	enemyPlane3->runAction(action3);

	auto enemyPlane4 = PlaneEnemy::createWithEnemyType(enemyType);
	enemyPlane4->setPosition(Vec2(X+50, 250));
	m_enemyList->addChild(enemyPlane4, 1, GameScene::ENEMY_TAG);
	enemyPlane4->runAction(action4);

	auto enemyPlane5 = PlaneEnemy::createWithEnemyType(8);
	enemyPlane5->setPosition(Vec2(X*0.5, winSize.height + 150));
	m_enemyList->addChild(enemyPlane5, 1, GameScene::ENEMY_TAG);
	enemyPlane5->runAction(action5);

}
void EnemyManager::addEnemyPlanes_12(float dt)
{
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	//int enemyType = PlaneEnemy::Enemy8;

	auto action1 = MoveTo::create(3, Vec2(X*0.2, Y*0.9));
	auto action2 = MoveTo::create(3, Vec2(X*0.5, 0.8*Y));
	auto action3 = MoveTo::create(3, Vec2(X*0.8, Y*0.9));
	auto action4 = MoveTo::create(3, Vec2(X*0.5, 0.7*Y));
	//auto action5 = MoveTo::create(3, Vec2(X*0.5, 0.6*Y));

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(7);
	enemyPlane1->setPosition(Vec2(-50, 150));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);
	enemyPlane1->runAction(action1);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(8);
	enemyPlane2->setPosition(Vec2(-50, 250));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);
	enemyPlane2->runAction(action2);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(7);
	enemyPlane3->setPosition(Vec2(X + 50, 150));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);
	enemyPlane3->runAction(action3);

	auto enemyPlane4 = PlaneEnemy::createWithEnemyType(6);
	enemyPlane4->setPosition(Vec2(X + 50, 250));
	m_enemyList->addChild(enemyPlane4, 1, GameScene::ENEMY_TAG);
	enemyPlane4->runAction(action4);

	//auto enemyPlane5 = PlaneEnemy::createWithEnemyType(5);
	//enemyPlane5->setPosition(Vec2(X*0.5, winSize.height + 150));
	//m_enemyList->addChild(enemyPlane5, 1, GameScene::ENEMY_TAG);
	//enemyPlane5->runAction(action5);


}
void EnemyManager::addEnemyPlanes_13(float dt)
{
	auto winSize = Director::getInstance()->getWinSize();
	int X = winSize.width;
	int Y = winSize.height;
	//int enemyType = PlaneEnemy::Enemy8;

	auto action1 = MoveTo::create(3, Vec2(X*0.2, Y*0.9));
	auto action2 = MoveTo::create(3, Vec2(X*0.3, 0.8*Y));
	auto action3 = MoveTo::create(3, Vec2(X*0.3, Y*0.7));
	auto action4 = MoveTo::create(3, Vec2(X*0.8, 0.9*Y));
	auto action5 = MoveTo::create(3, Vec2(X*0.7, 0.8*Y));
	auto action6 = MoveTo::create(3, Vec2(X*0.7, 0.7*Y));

	auto enemyPlane1 = PlaneEnemy::createWithEnemyType(3);
	enemyPlane1->setPosition(Vec2(-50, 350));
	m_enemyList->addChild(enemyPlane1, 1, GameScene::ENEMY_TAG);
	enemyPlane1->runAction(action1);

	auto enemyPlane2 = PlaneEnemy::createWithEnemyType(3);
	enemyPlane2->setPosition(Vec2(-50, 250));
	m_enemyList->addChild(enemyPlane2, 1, GameScene::ENEMY_TAG);
	enemyPlane2->runAction(action2);

	auto enemyPlane3 = PlaneEnemy::createWithEnemyType(3);
	enemyPlane3->setPosition(Vec2(-50, 150));
	m_enemyList->addChild(enemyPlane3, 1, GameScene::ENEMY_TAG);
	enemyPlane3->runAction(action3);

	auto enemyPlane4 = PlaneEnemy::createWithEnemyType(3);
	enemyPlane4->setPosition(Vec2(X + 50, 350));
	m_enemyList->addChild(enemyPlane4, 1, GameScene::ENEMY_TAG);
	enemyPlane4->runAction(action4);

	auto enemyPlane5 = PlaneEnemy::createWithEnemyType(3);
	enemyPlane5->setPosition(Vec2(X+50,250));
	m_enemyList->addChild(enemyPlane5, 1, GameScene::ENEMY_TAG);
	enemyPlane5->runAction(action5);

	auto enemyPlane6 = PlaneEnemy::createWithEnemyType(3);
	enemyPlane6->setPosition(Vec2(X+50, 150));
	m_enemyList->addChild(enemyPlane6, 1, GameScene::ENEMY_TAG);
	enemyPlane6->runAction(action6);
}

void EnemyManager::addEnemys(float dt)
{
	auto count= m_enemyList->getChildrenCount();
	//log("%d", count);
	if (count <= 0)
	{		
		
		switch (m_time)
		{
		case 1:
			scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_9), 0.5);
			m_time++;
			break;
		case 2:
			scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_11),0.5);
			m_time++;
			break;
		case 3:
			scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_10), 0.5);
			m_time++;
			break;
		case 4:
			scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_9), 0.5);
			m_time++;
			break;
		case 5:
			scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_12), 0.5);
			m_time++;
			break;
		case 6:
			scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_11), 0.5);
			m_time++;
			break;
		case 7:
			scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_13), 0.5);
			m_time++;
			break;
		case 8:
			scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_10), 0.5);
			m_time++;
			break;
		case 9:
			scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_12), 0.5);
			m_time++;
			break;
			break;
		case 10:
			scheduleOnce(schedule_selector(EnemyManager::addEnemyPlanes_13), 0.5);
			m_time++;
			break;
		case 11:
			scheduleOnce(schedule_selector(EnemyManager::addBoss), 0.5);
			m_time++;
			break;

		default:
			unschedule(schedule_selector(EnemyManager::addEnemys));
			//log("cancle");
			break;
		}
	}

}