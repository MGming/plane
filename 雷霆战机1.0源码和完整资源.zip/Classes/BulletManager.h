#pragma once
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class BulletManager:public cocos2d::Layer
{
public:
	bool init();	
	void removeBullet(float dt);
	SpriteBatchNode* getBulletList() { return m_bulletList; };
	CREATE_FUNC(BulletManager);
private:
	SpriteBatchNode* m_bulletList;
};
