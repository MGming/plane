#pragma once
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;

class HeroBullet :public Sprite
{
public:
	enum HeroBulletType
	{
		CCC,
		CCB,
		CCA,
		CBC,
		CAC,
		BCC,
		ACC,
		BBB,
		AAA

	};
	enum HeroBulletPower
	{
		AMETHYST,
		RUBY,
		SAPPHIRE,
		GOLD
	};

public:
	static HeroBullet* createWithBulletType(float v,int p,int t);
	bool init(float v,int p,int t);
	int getBulletPower() { return m_bulletPower; }
	//void onEnter();
private:
		
	float m_bulletVec;//�ٶ�
	int m_bulletPower;//����
	int m_bulletType;//����
	int m_isLive;
};