#include"PlaneHero.h"
#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"GameScene.h"
#include"HeroBullet.h"
#include"SoundManager.h"

USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;
Vec2 PlaneHero::heroPos = Vec2(0, 0);
bool PlaneHero::init()
{  
	if (!Sprite::init())
	{
		return false;
	}
	this->initWithSpriteFrameName("Plane0_0.png");	
	this->setAnchorPoint(Vec2(0.5, 0.5));
	this->setName("plane0");
	//��������ģ��
	Vec2 verts[3]= { Vec2(-10, -10), Vec2(0, 10), Vec2(10, -10) };//���ݵ����һ�������,����������
	auto herobody = PhysicsBody::create();
	herobody->addShape(PhysicsShapePolygon::create(verts, 3));//��һ��Ҫ˳ʱ����д,PhysicsShapeEdgePolygon::create����
	herobody->setCategoryBitmask(GameScene::CategoryMaskBit::HERO_CATEGORYMASKBIT);
	herobody->setCollisionBitmask(0); //��������ײģ��,����Ҫ
	herobody->setContactTestBitmask(GameScene::ContactMaskBit::HERO_CONTACTMASKBIT);
	herobody->setVelocity(Vect(0, 0));
	this->setPhysicsBody(herobody);
	this->m_heroLife = 1;
	this->m_bulletVec = 1;
	this->m_bulletPower = 1;
	this->m_bulletNumber = 1;
	return true;
}

void PlaneHero::onEnter()
{   
	Sprite::onEnter();

	//�������ж���
	auto animation = Animation::create();
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Plane0_0.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Plane0_1.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Plane0_2.png"));
	animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName("Plane0_3.png"));
	animation->setDelayPerUnit(0.1);//��������֡����ʱ����
	animation->setLoops(-1);//�����Ƿ�ѭ������,-1����ѭ��,����n����n��,0������
	animation->setRestoreOriginalFrame(true);//���ö�����������Ƿ�ص���һ֡
	auto fly = Animate::create(animation);
	this->runAction(fly);
	
	schedule(schedule_selector(PlaneHero::updatePosition), 0.1);
	schedule(schedule_selector(PlaneHero::isCleanup));
}

void PlaneHero::updatePosition(float dt)
{
	heroPos = this->getPosition();
}

Vec2 PlaneHero::sharePosition()
{
	return heroPos;
}
void PlaneHero::beginShooting(float dt)
{
//	SimpleAudioEngine::getInstance()->playEffect("Shoot.mp3");

	if (m_bulletNumber == 1)
	{
		//����һ���ӵ������뵽GameLayer���ӵ���Ⱦ����
		auto bullet = HeroBullet::createWithBulletType(1, this->m_bulletPower, 1);
		bullet->setPosition(Vec2(this->getPosition().x, this->getPosition().y + 0.5*this->getContentSize().height));
		GameScene::getBulletManager()->getBulletList()->addChild(bullet, 0, GameScene::HERO_BULLET_TAG);
	}
	else if (m_bulletNumber == 2)
	{
		//���������ӵ������뵽GameLayer���ӵ���Ⱦ����
		auto bullet1 = HeroBullet::createWithBulletType(1, this->m_bulletPower, 1);
		bullet1->setPosition(Vec2(this->getPosition().x-5, this->getPosition().y + 0.5*this->getContentSize().height));
		GameScene::getBulletManager()->getBulletList()->addChild(bullet1, 0, GameScene::HERO_BULLET_TAG);

		auto bullet2 = HeroBullet::createWithBulletType(1, this->m_bulletPower, 1);
		bullet2->setPosition(Vec2(this->getPosition().x +5, this->getPosition().y + 0.5*this->getContentSize().height));
		GameScene::getBulletManager()->getBulletList()->addChild(bullet2, 0, GameScene::HERO_BULLET_TAG);
	}

	else
	{

		//���������ӵ������뵽GameLayer���ӵ���Ⱦ����
		auto bullet1 = HeroBullet::createWithBulletType(1, this->m_bulletPower, 1);
		bullet1->setPosition(Vec2(this->getPosition().x - 10, this->getPosition().y + 0.5*this->getContentSize().height));
		GameScene::getBulletManager()->getBulletList()->addChild(bullet1, 0, GameScene::HERO_BULLET_TAG);

		auto bullet2 = HeroBullet::createWithBulletType(1, this->m_bulletPower, 1);
		bullet2->setPosition(Vec2(this->getPosition().x + 10, this->getPosition().y + 0.5*this->getContentSize().height));
		GameScene::getBulletManager()->getBulletList()->addChild(bullet2, 0, GameScene::HERO_BULLET_TAG);

		auto bullet3 = HeroBullet::createWithBulletType(1, this->m_bulletPower, 1);
		bullet3->setPosition(Vec2(this->getPosition().x, this->getPosition().y + 0.5*this->getContentSize().height));
		GameScene::getBulletManager()->getBulletList()->addChild(bullet3, 0, GameScene::HERO_BULLET_TAG);

	}
}
void PlaneHero::getItem(Item* item)
{
	if (item->getName()== "Gold")
	{
		SoundManager::playGainGoldSound();
		GameScene::getMessageManager()->addScore(item->buff.s);
		return;
	}
	SoundManager::playGainJewelSound();
	(this->m_bulletVec)+=item->buff.v;
	(this->m_bulletPower)+= item->buff.p;
	(this->m_bulletNumber)+= item->buff.n;

	//����vpn������
	if (this->m_bulletVec <= 3)
	{
		unschedule(schedule_selector(PlaneHero::beginShooting));
		schedule(schedule_selector(PlaneHero::beginShooting), 0.3 / this->m_bulletVec);
	}
	if (this->m_bulletPower > 3)
		this->m_bulletPower = 3;

	if (this->m_bulletNumber > 3)
		this->m_bulletNumber= 3;

}

void PlaneHero::getHurt(int bulletPower)
{
	auto winSize = Director::getInstance()->getWinSize();
	if ((this->getPositionY()) > (winSize.height - this->getContentSize().height / 2))
		return;
	m_heroLife -= bulletPower;
	//log("hurt");

}
void PlaneHero::blowUp()
{
	this->getPhysicsBody()->removeFromWorld();  //�����������ƿ�,�㲻�ᷢ������ģ����
	unscheduleAllSelectors();
	//unschedule(schedule_selector(PlaneHero::beginShooting));
	this->stopAllActions();
	//this->onExit();
	auto animation = Animation::create();
	char str[64] = { 0 };
	for (int i = 1; i <= 35; i++)
	{
		sprintf(str, "explosion_%02d.png", i);
		animation->addSpriteFrame(SpriteFrameCache::getInstance()->getSpriteFrameByName(str));
		//log("%s", str);
	}
	animation->setDelayPerUnit(0.083);//��������֡����ʱ����
	animation->setLoops(1);//�����Ƿ�ѭ������,-1����ѭ��
	animation->setRestoreOriginalFrame(true);//���ö�����������Ƿ�ص���һ֡
	auto blowUp = Animate::create(animation);
	auto remove = CallFunc::create([this]() {this->removeFromParent(); });
	auto action = Sequence::create(blowUp, remove, nullptr);
	this->runAction(action);
	SoundManager::playBlowUpSound();
}
void PlaneHero::isCleanup(float dt)
{
	
	if (m_heroLife <= 0)
	{
		//this->stopAllActions();
		this->blowUp();
		//log("remove hero");
		return;
	}
}
bool PlaneHero::isLive()
{
	if (this->m_heroLife <= 0)
		return false;
	else
		return true;

}
