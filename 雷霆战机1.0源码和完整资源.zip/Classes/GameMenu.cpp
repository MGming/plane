#include"GameMenu.h"
#include "GameScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"
#include"OptionScene.h"
#include"SoundManager.h"


USING_NS_CC;
using namespace cocostudio::timeline;
using namespace cocos2d::ui;
using namespace CocosDenshion;

Scene* GameMenu::createScene()
{
	auto scene = Scene::create();
	auto layer = GameMenu::create();
	scene->addChild(layer);
	return scene;
}
bool GameMenu::init()
{
	if (!Layer::init())
	{
		return false;
	}

	//Ԥ������Դ��������
	this->preloadSources();    

	if (UserDefault::getInstance()->getBoolForKey("isFileExit") != 1)
	{
		auto userdefault = UserDefault::getInstance();
		userdefault->setBoolForKey("isFileExit", 1);
		userdefault->setBoolForKey("bgmSwitch", 1);
		userdefault->setBoolForKey("effectSwitch", 1);
		userdefault->flush();
		//log("restart");
	}

	SoundManager::refresh();        //ˢ��һ����Ч����
	SoundManager::playMenuBgm();    //���ű�������
		
    //����˵�ͼ��
	auto menuLayer = CSLoader::createNode("GameMenu.csb");
	menuLayer->setAnchorPoint(Vec2(0, 0));
	menuLayer->setPosition(Vec2(0, 0));
	this->addChild(menuLayer);

	//��ȡ��ť
	m_panel = (Layout*)menuLayer->getChildByName("Panel");
	m_startButton = (Button*)Helper::seekWidgetByName(m_panel, "StartButton");
	m_optionButton = (Button*)Helper::seekWidgetByName(m_panel, "OptionButton");
	m_exitButton = (Button*)Helper::seekWidgetByName(m_panel, "ExitButton");

	//���¼�
	m_startButton->addTouchEventListener(CC_CALLBACK_2(GameMenu::startGame, this));
	m_optionButton->addTouchEventListener(CC_CALLBACK_2(GameMenu::option, this));
	m_exitButton->addTouchEventListener(CC_CALLBACK_2(GameMenu::exitGame, this));



	return true;
}
void GameMenu::preloadSources()
{
	//����plist�ļ�
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Bullet.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Show.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Plane.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Boss.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Item.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("Enemy.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("explosion.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("zanting.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("settings.plist");
	SpriteFrameCache::getInstance()->addSpriteFramesWithFile("fight.plist");

	//��������
	auto audioengine = SimpleAudioEngine::getInstance();
	audioengine->preloadBackgroundMusic("Stage1.mp3");
	audioengine->preloadEffect("Shoot.mp3");
	audioengine->preloadEffect("Explosion.mp3");
	audioengine->preloadEffect("GainJewel.mp3");
	audioengine->preloadEffect("GainGold.mp3");
	audioengine->preloadEffect("Countdown.mp3");
	audioengine->preloadEffect("Pause.mp3");
	audioengine->preloadEffect("Sure.mp3");
	audioengine->preloadEffect("Title.mp3");
	audioengine->preloadEffect("Entry.mp3");
	audioengine->preloadEffect("MissionStart.mp3");
	audioengine->preloadEffect("MissionComplete.mp3");
	audioengine->preloadEffect("Shoot.mp3");
	audioengine->preloadEffect("Stage2.mp3");
	audioengine->preloadEffect("Warning.mp3");
}
void GameMenu::unloadSources()
{
	SpriteFrameCache::getInstance()->destroyInstance();
	SimpleAudioEngine::getInstance()->end;

	/**
	auto audioengine = SimpleAudioEngine::getInstance();
	audioengine->unloadEffect("Stage1.mp3");
	audioengine->unloadEffect("Shoot.mp3");
	audioengine->unloadEffect("Explosion.mp3");
	audioengine->unloadEffect("GainJewel.mp3");
	audioengine->unloadEffect("GainGold.mp3");
	audioengine->unloadEffect("Countdown.mp3");
	audioengine->unloadEffect("Pause.mp3");
	audioengine->unloadEffect("Sure.mp3");
	audioengine->unloadEffect("Title.mp3");
	audioengine->unloadEffect("Entry.mp3");
	audioengine->unloadEffect("MissionStart.mp3");
	audioengine->unloadEffect("MissionComplete.mp3");
	audioengine->unloadEffect("Shoot.mp3");
	audioengine->unloadEffect("Stage2.mp3");
	audioengine->unloadEffect("Warning.mp3");
	*/
}
void GameMenu::startGame(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		SoundManager::playSureSound();
		Director::getInstance()->replaceScene(TransitionFade::create(0.1f, GameScene::createScene()));
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}
}
void GameMenu::option(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		SoundManager::playSureSound();
		Director::getInstance()->replaceScene(TransitionFade::create(0.1f, OptionScene::createScene()));
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;
	}
}
void GameMenu::exitGame(cocos2d::Object* pSender, Widget::TouchEventType type)
{
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		break;
	case Widget::TouchEventType::MOVED:
		break;
	case Widget::TouchEventType::ENDED:
		this->unloadSources();
		Director::getInstance()->end();
		break;
	case Widget::TouchEventType::CANCELED:
		break;
	default:
		break;

	}
}
